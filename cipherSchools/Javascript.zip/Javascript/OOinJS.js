// Object Oriented Javascript


    // let user = {
    //     name: 'Jake',
    //     email: 'jake@abc.com',
    //     login() { 
    //         console.log('Inside Login', this);       
    //         console.log(name, 'has logged in!')
    //     },
    //     logout(){
    //         console.log(this);
    //         console.log(this.name, 'has logged out!')
    //     }
    // }

    // this.console.log(this);
    // user.login();
    // user.logout();

// Class Keyword - es6 syntatical Sugar

class User{
    constructor(name, email){
        this.name = name;
        this.email = email;
        this.count = 0;
    }
    login(){
        console.log(this.email, 'has logged in!!')
        return this;
    }
    logout(){
        console.log(this.email, 'has logged out!!')
    }
    updateCount(){
        this.count++;
        return this;
    }
}

let newUser = new User('Jake', 'jake@abc.com');
let userTwo = new User('Jane', 'jane@abc.com');

console.log(newUser);
// Method Chaining 
newUser
    .login()
    .updateCount()
    .updateCount()
    .updateCount()
    .logout();


// console.log(userTwo.login().updateCount().updateCount());

userTwo.login().updateCount().updateCount().logout();


console.log(userTwo.count);
console.log(newUser.count);