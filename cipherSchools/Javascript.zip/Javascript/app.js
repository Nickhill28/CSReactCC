// Tim berner Lee 
// Sun microsystems - Mozilla Parent

// Interpreter - line by line 

// ECMA - standardization for JS
// ES2020 
// ES6/ECMA 2015 after ES5

// Datatypes - Number String Null Undefined Boolean Objects Symbols(es6)

// var age = 10;
// var name = 'John';
// //            0123456789
// var phrase = "Good Afternoon!! What's the time";

// String Methods
    // console.log(age.length);
    // console.log(phrase.length); // Property
    // console.log(phrase.toUpperCase()); // Methods
    // console.log(phrase.toLowerCase());

    // console.log(phrase.substr(2, 5));
    // console.log(phrase.substring(2, 5));
    // var str = phrase.substring(2, 5).length;

    // console.log(phrase.toUpperCase().lastIndexOf('A'));

// Number - arithematic operations
// BEDMAS rule;

    // var expression = 2*(5**2/5)+2/2;
    // console.log(expression);

    // var sum = 10 + 10;
    // var val = 2**10;
    // console.log(sum, val);

// Output questions:

    //  var age = 10;

    //  var sum = 10 + '10';
    //  console.log(sum);

    //  console.log('name'+'age');

// Boolean Null Undefined

// var isLogin = false;
// var customer;
// var accountBalance = null;

// console.log(isLogin, customer, accountBalance);

// var val = 'name';
// console.log(val*10);


// if(val){
//     console.log('It is true');
// }else{
//     console.log('It is False');
// }

// Truthy and Falsy
// Truthy - value, number string 1 true infinity
// Falsy - undefined null false 0 '' NaN

// var val = 10 - 'alphabet';
// // console.log(val);

// console.log(typeof '');
// console.log(typeof true);
// console.log(typeof 'alphabet');
// console.log(typeof null); // *

// Explicit Conversion

// var val;

// console.log(Number(val));
// var str = (typeof '');

// console.log(Boolean(str));
// console.log(Boolean(''));

