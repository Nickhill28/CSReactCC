//Global scope and functional Scope

    // var age = 10;

    // var name= 'Harry';
    // function display(){
    //     var name='Ron';
    //     name= 'Hagrid';
    //     console.log(name, age);
    // }

    // console.log(name);
    // display();

// ES6 features

// let, const, arrow functions, destructing of objects, rest syntax

    // let age = 10;

    // if(true){
    //     // Let and const are block scoped
    //     let age = 15;
    //     console.log(age);   
    // }

    // function display(){
    //     // let age = 12;
    //     console.log(age);
    //     if(true){
    //         let age = 20;
    //         var rollNo = 'AB1234';
    //         console.log(age);
    //     }
    //     console.log(rollNo);
    // }

    // console.log(rollNo);

    // // console.log(age);
    // display();
    // console.log(age);

// const

if(true){
    const PI = 3.14;
    console.log(PI);
}

console.log(PI);
