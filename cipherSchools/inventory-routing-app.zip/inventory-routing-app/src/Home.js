import React from 'react';

const Home = props => {
    return(
        <div>
            <h3>Home {console.log(props)}</h3>
        </div>
    )
}

export default Home;